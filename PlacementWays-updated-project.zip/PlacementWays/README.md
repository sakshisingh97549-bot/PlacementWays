# PlacementWays

The application from `placementways-updated-project.zip` is extracted in
[`placementways/`](placementways/). The original upload is preserved.

```sh
cd placementways
npm ci
# Configure .env.local and apply Supabase migrations; see docs/SUPABASE_SETUP.md.
npm run dev
```

See [access control and guest-mock setup](placementways/docs/ACCESS_CONTROL.md),
[application documentation](placementways/README.md), and
[development status](placementways/docs/DEVELOPMENT_STATUS.md).
