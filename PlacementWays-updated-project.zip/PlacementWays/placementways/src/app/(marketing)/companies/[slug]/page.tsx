import { publicMetadata } from "@/lib/seo";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getPublishedCompany } from "@/server/companies/queries";
export default async function CompanyPage({
  params,
}: PageProps<"/companies/[slug]">) {
  const company = await getPublishedCompany((await params).slug);
  if (!company) notFound();
  return (
    <div className="mx-auto w-full max-w-5xl space-y-8 px-6 py-12">
      <nav aria-label="Breadcrumb">
        <Link href="/companies" className="underline">
          Companies
        </Link>{" "}
        / {company.name}
      </nav>
      <div>
        <h1 className="font-serif text-4xl">{company.name}</h1>
        <p className="mt-4 whitespace-pre-wrap leading-7">
          {company.description}
        </p>
      </div>
      <div className="flex flex-wrap gap-5">
        <Link className="underline" href={`/courses?company=${company.id}`}>
          Explore courses
        </Link>
        <Link className="underline" href={`/tests?company=${company.slug}`}>
          Explore mock tests
        </Link>
        {company.website_url && (
          <a
            className="underline"
            href={company.website_url}
            rel="noopener noreferrer"
            target="_blank"
          >
            Official website
          </a>
        )}
      </div>
      <h2 className="font-serif text-3xl">Recruitment process</h2>
      {!company.processes.length && (
        <p>
          Verified recruitment details have not been published yet. Check the
          company’s official careers website for current eligibility and hiring
          announcements.
        </p>
      )}
      {company.processes.map((p) => (
        <section
          key={p.id}
          className="space-y-5 rounded-xl border border-[var(--color-line)] p-6"
        >
          <h3 className="font-serif text-2xl">{p.title}</h3>
          <p>{[p.drive_name, p.hiring_year].filter(Boolean).join(" · ")}</p>
          <p className="whitespace-pre-wrap">{p.description}</p>
          {p.eligibility && (
            <div>
              <h4 className="font-semibold">Eligibility</h4>
              <p className="mt-2 whitespace-pre-wrap">{p.eligibility}</p>
            </div>
          )}
          <ol className="space-y-4">
            {p.process_stages
              .sort((a, b) => a.stage_order - b.stage_order)
              .map((s) => (
                <li key={s.id}>
                  <h4 className="font-semibold">
                    {s.stage_order}. {s.name}
                  </h4>
                  <p className="whitespace-pre-wrap">{s.description}</p>
                  <p className="text-sm">{s.topics.join(" · ")}</p>
                  {(s.duration_minutes ?? 0) > 0 && (
                    <p className="text-sm">{s.duration_minutes} minutes</p>
                  )}
                  {(s.question_count ?? 0) > 0 && (
                    <p className="text-sm">{s.question_count} questions</p>
                  )}
                </li>
              ))}
          </ol>
          <p className="text-sm">
            Last verified: {p.last_verified_on}. Hiring requirements may change;
            confirm against the sources below.
          </p>
          <ul className="space-y-2">
            {p.process_sources
              .sort((a, b) => a.sort_order - b.sort_order)
              .map((s) => (
                <li key={s.id}>
                  <a
                    className="underline"
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

export async function generateMetadata({params}:PageProps<"/companies/[slug]">){const {slug}=await params;const item=await getPublishedCompany(slug);return publicMetadata(item?.name??"Company",item?.description,`/companies/${slug}`);}
