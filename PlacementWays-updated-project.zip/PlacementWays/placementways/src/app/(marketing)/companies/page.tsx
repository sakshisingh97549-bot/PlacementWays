import Link from "next/link";
import { getPublishedCompanies } from "@/server/companies/queries";
export const metadata = { title: "Company preparation" };
export default async function CompaniesPage({
  searchParams,
}: PageProps<"/companies">) {
  const params = await searchParams;
  const q = typeof params.q === "string" ? params.q.slice(0, 100).trim() : "";
  const companies = (await getPublishedCompanies()).filter((c) =>
    `${c.name} ${c.description ?? ""}`.toLowerCase().includes(q.toLowerCase()),
  );
  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-12">
      <h1 className="font-serif text-4xl">Find your preparation path</h1>
      <p className="mt-4">Explore company guides, courses and mock tests.</p>
      <form className="my-8 flex flex-wrap gap-3" role="search">
        <label className="sr-only" htmlFor="company-search">
          Search companies
        </label>
        <input
          id="company-search"
          name="q"
          defaultValue={q}
          maxLength={100}
          placeholder="Search companies"
          className="min-w-0 rounded border p-3"
        />
        <button className="rounded bg-[var(--color-ink)] px-5 py-3 text-white">
          Search
        </button>
      </form>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {companies.map((c) => (
          <article
            key={c.id}
            className="rounded-xl border border-[var(--color-line)] p-6"
          >
            <h2 className="font-serif text-2xl">
              <Link
                href={`/companies/${c.slug}`}
                className="underline underline-offset-4"
              >
                {c.name}
              </Link>
            </h2>
            <p className="mt-3 text-sm leading-7">{c.description}</p>
          </article>
        ))}
      </div>
      {!companies.length && (
        <p>No published companies match your search yet.</p>
      )}
    </div>
  );
}
