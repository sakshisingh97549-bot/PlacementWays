import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  poweredByHeader:false,
  experimental:{serverActions:{bodySizeLimit:"12mb"}},
  async headers(){return [{source:"/:path*",headers:[
    {key:"X-Content-Type-Options",value:"nosniff"},
    {key:"X-Frame-Options",value:"DENY"},
    {key:"Referrer-Policy",value:"strict-origin-when-cross-origin"},
    {key:"Permissions-Policy",value:"camera=(), microphone=(), geolocation=()"},
    ...(process.env.DEPLOYMENT_ENV === "production" ? [{key:"Strict-Transport-Security",value:"max-age=31536000"}] : []),
  ]}];},
};
export default nextConfig;
