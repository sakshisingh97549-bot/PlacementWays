# Updated PlacementWays project

This export contains the current source, CI workflow, database migrations, tests and documentation.
It includes uncommitted task changes. The original uploaded ZIP, Git history, dependencies,
build output and local credentials are excluded. No production secrets are included.

## Start here

The application directory is `placementways/` inside this archive's `PlacementWays/` folder.
Use Node24, run `npm ci`, and configure `.env.local` using `.env.example`.
Follow `placementways/docs/SUPABASE_SETUP.md` and `placementways/docs/PRODUCTION_RELEASE.md`.
The coding worker requires a separately configured isolated execution provider.

## Release status

This is a locally validated implementation candidate, not a production-certified deployment.
Previous validation passed: build/HTTP smoke, TypeScript, lint,174 unit tests,17 SQL suites,
guest/scoped concurrency, selected browser flows, compiler/worker probes and local restore.
Stripe HTTP boundary checks used signed synthetic events; full provider checkout remains unverified.

Production Supabase/Auth/email/Storage, trusted ingress, hosting/domain, dedicated compiler,
Stripe test-mode checkout/refund, reviewed recruitment content and owner policies, monitoring,
capacity and hosted backup/restore verification remain release gates.

Three minor review follow-ups remain: future function-overload support in type generation,
stricter bounds for manually supplied admin question pagination, and defensive SubmitButton props.
The reported historical global-lock warning is resolved by the later scoped-lock migration.

`MANIFEST.sha256` records the SHA-256 of each included repository file.
